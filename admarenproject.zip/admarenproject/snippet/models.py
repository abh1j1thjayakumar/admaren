from django.db import models
from users.models import Users
# Create your models here.


class SnippetModel(models.Model):

    class Meta:
        db_table = 'snippet_db'

    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=100, null=False)
    snippet = models.CharField(max_length=299, null=False)
    timestamp = models.DateTimeField(auto_now_add=True)
    created_user = models.ForeignKey(Users, on_delete=models.CASCADE, related_name='created_user')
    



