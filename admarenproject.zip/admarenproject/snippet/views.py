from . serializers import snippetSerializer
from . models import SnippetModel
# Create your views here.
from rest_framework import permissions
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.authtoken.models import Token
from rest_framework.permissions import IsAuthenticated
from rest_framework.authentication import TokenAuthentication
from users.models import Users
from django.contrib.auth import authenticate
from django.core.paginator import Paginator , PageNotAnInteger , EmptyPage
from tags.models import tagModel

class SnippetCreate(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):

        data = {}
        serializer = snippetSerializer(data= request.data)
        current_user = request.user
        print(current_user)
        users = Users.objects.get(email=current_user)
        user_id = users.id
        print(user_id)
        #print(current_user.id)
        if serializer.is_valid():
            serializer.save(created_user_id=user_id)
            snippet_data = serializer.data
            snippet_title = snippet_data['title']
            if tagModel.objects.filter(title=snippet_title).exists():
                pass
            else:
                tagModel.objects.create(title=snippet_data['title'])
                print(snippet_title)
            data['data'] = serializer.data
            data['Success'] = 1
            data['Message'] = 'Snippet Created Successfully'
            return Response(data,status=status.HTTP_200_OK)
        else:
            data['data'] = serializer.errors
            data['success']=0
            data['message'] = 'Error Snippet Create Failed !'

            return Response(data,status=status.HTTP_400_BAD_REQUEST)
        

class SnippetView(APIView):
    permission_classes = [IsAuthenticated]


    def post(self, request, *args, **kwargs):

        snipped_id = request.data['id']
        data = {}
        print(snipped_id)
        snippet = SnippetModel.objects.get(id=snipped_id)
        serializer = snippetSerializer(snippet)
        data['data'] = serializer.data
        data['Success'] = 1
        data['Message'] = 'Snippet View Successfully'

        return Response(data,status=status.HTTP_200_OK)

class SnippetUpdate(APIView):
    permission_classes = [IsAuthenticated]


    def post(self,request):
        data ={}

        snipppet_data = request.data
        snippet_id = request.data['id']
        snippet = SnippetModel.objects.get(id=snippet_id)
        serializer = snippetSerializer(snippet,data=snipppet_data)
        if serializer.is_valid():
            serializer.save()
            data['data'] = serializer.data
            data['Success'] = 1
            data['Message'] = 'Snippet Update Successfully'
            return Response(data,status=status.HTTP_200_OK)
        else:
            data['data'] = serializer.errors
            data['Success'] = 0
            data['Message'] = 'Snippet Update Failed'
            return Response(data,status=status.HTTP_400_BAD_REQUEST)



class SnippetDelete(APIView):
    permission_classes = [IsAuthenticated]


    def post(self,request):
        data = {}
        snipppet_id = request.data['id']
        try:
            snippet = SnippetModel.objects.get(id=snipppet_id)
            snippet.delete()
            data['data'] = ''
            data['Success'] = 1
            data['Message'] = 'Snippet Delete Successfully'
            return Response(data,status=status.HTTP_200_OK)

        except:
            data['data'] = ''
            data['Success'] = 0
            data['Message'] = 'Snippet Delete Failed'
            return Response(data,status=status.HTTP_400_BAD_REQUEST)




'''class SnippetList(APIView):
    authentication_classes = [TokenAuthentication]
    permission_classes = [IsAuthenticated]

    def post(self,request):
        data = {}
        snipppet_id = request.data['id']
        snippet = SnippetModel.objects.all()
        serializer = snippetSerializer(snippet,many=True)
        data['data'] = serializer.data
        data['Success'] = 1
        data['Message'] = 'Snippet List Successfully'
        return Response(data,status=status.HTTP_200_OK)'''


class SnippetList(APIView):
    permission_classes = [IsAuthenticated]
    


    def post(self,request):
        data = {}
        
        content = request.data
        try:
            search = content['search']
            page = content['page']
            orderings = content['sort_col']
            sort = content['sort']
            page_index = content['page_index']

        except:
            data['data'] = ''
            data['success'] = 0
            data['message'] = 'Input data required , required fields (search,sort_col,sort,page,page_index)'
            return Response(data,status=status.HTTP_400_BAD_REQUEST)
        len_search=[x for x in search.split()]

        if len(len_search) !=0:
        
            search_display = SnippetModel.objects.filter(
                title__icontains=search) 


        else:
            search_display = SnippetModel.objects.all()

        serializers = snippetSerializer(search_display,many=True)

        lenorder=[x for x in orderings.split()]
        if len(lenorder) !=0:
            #print('testing empty')
            if sort == 0:

                #search_data = search_display.values().order_by(orderings).reverse()
                search_data=sorted(serializers.data, key=lambda k: k[orderings], reverse=True)
                


            elif sort ==1:
                #search_data = search_display.values().order_by(orderings)
                search_data=sorted(serializers.data, key=lambda k: k[orderings])
                


            else :
                data['data'] = ''
                data['success'] = 0
                data['message'] = 'sorrting error sort by 1 or 0'


                return Response(data,status=status.HTTP_200_OK)
        else:
            search_data = serializers.data

        total =search_display.count()
        paginator = Paginator(search_data, page_index)

        try:
            page_datas = paginator.page(page)
        except PageNotAnInteger:
            page_datas = paginator.page(1)
        except EmptyPage:
            page_datas = paginator.page(paginator.num_pages)

       
        data['data'] = list(page_datas)
        data['total'] = total
        data['success'] = 1
        data['message'] = 'customer list executed successfully'
        

        return Response(data,status=status.HTTP_200_OK)

        
    

    
       