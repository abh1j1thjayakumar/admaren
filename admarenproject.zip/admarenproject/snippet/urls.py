from django.contrib import admin
from django.urls import path
from . views import SnippetCreate,SnippetView,SnippetUpdate,SnippetDelete,SnippetList

urlpatterns = [
    path('create/',SnippetCreate.as_view()),
    path('view/',SnippetView.as_view()),
    path('update/',SnippetUpdate.as_view()),
    path('delete/',SnippetDelete.as_view()),
    path('list/',SnippetList.as_view()),




    


]



