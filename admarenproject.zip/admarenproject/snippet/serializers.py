from dataclasses import field
from rest_framework import serializers

from . models import SnippetModel


class snippetSerializer(serializers.ModelSerializer):

    class Meta:

        model = SnippetModel
        fields = ['id','title','timestamp','created_user','snippet']

        extra_kwargs = {
            'created_user': {'read_only': True},
            'timestamp': {'read_only': True}
        }
        