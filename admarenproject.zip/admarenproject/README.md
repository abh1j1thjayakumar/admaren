# REST API

The REST API to the Admaren Project is described below.

## Register User

### Request

`POST /api/user/register/`

    curl -i -H 'Accept: application/json' http://127.0.0.1:8000/api/user/register/

### Response

    HTTP/1.1 200 OK
    Status: 200 OK
    Connection: close
    Content-Type: application/json
    
    {
    "data": {
    "id": 1,
    "name": "admin",
    "email": "admin@gmail.com"
    },
    "Success": 1,
    "Message": "User Created Successfully"
}
    
    
### Input

    {
    "name": "admin",
    "email":"admin@gmail.com",
    "password":"admin"
    }


## Login User

### Request

`POST /api/user/login/`

    curl -i -H 'Accept: application/json' http://127.0.0.1:8000/api/user/login/

### Response

    HTTP/1.1 200 OK
    Status: 200 OK
    Connection: close
    Content-Type: application/json
    
    {
    "data": {
        "id": 1,
        "name": "admin",
        "email": "admin@gmail.com"
    },
    "token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJlbWFpbCI6ImFkbWluQGdtYWlsLmNvbSJ9.xmcDPn80cdQ1ayQAb1Qbun92W6hYP4wFvpHw4ilBGEU",
    "success": 1,
    "Message": "User Logged in Successfully"
}
    
    
### Input

    {
    "email":"admin@gmail.com",
    "password":"admin"
}

## Create Snippet

### Request

`POST /api/snippet/create/`

    curl -i -H 'Accept: application/json' Autherization : Bearer "token" http://127.0.0.1:8000/api/snippet/create/

### Response

    HTTP/1.1 200 OK
    Status: 200 OK
    Connection: close
    Content-Type: application/json
    {
    "data": {
        "id": 7,
        "title": "creating",
        "timestamp": "2022-03-03T07:44:19.565954Z",
        "created_user": 7,
        "snippet": "creating texting"
    },
    "Success": 1,
    "Message": "Snippet Created Successfully"
}
    
### Input

    {
    "title":"creating",
    "snippet":"creating texting"
    }




## View Snippet 

### Request

`POST /api/snippet/view/`

    curl -i -H 'Accept: application/json' Autherization : Bearer "token" http://127.0.0.1:8000/api/snippet/view/

### Response

    HTTP/1.1 200 OK
    Status: 200 OK
    Connection: close
    Content-Type: application/json
    {
    "data": {
        "id": 3,
        "title": "test",
        "timestamp": "2022-03-02T11:05:36.685164Z",
        "created_user": 7
    },
    "Success": 1,
    "Message": "Snippet View Successfully"
}
    
### Input

    {
    "id" :3
    }




## Update Snippet

### Request

`POST /api/snippet/update/`

    curl -i -H 'Accept: application/json' Autherization : Bearer "token" http://127.0.0.1:8000/api/snippet/update/

### Response

    HTTP/1.1 200 OK
    Status: 200 OK
    Connection: close
    Content-Type: application/json
    {
    "data": {
        "id": 3,
        "title": "testUpdate",
        "timestamp": "2022-03-02T11:05:36.685164Z",
        "created_user": 7
    },
    "Success": 1,
    "Message": "Snippet Update Successfully"
}
    
### Input

    {
    "id":3,
    "title":"testUpdate"
    }



## Delete Snippet

### Request

`POST /api/snippet/delete/`

    curl -i -H 'Accept: application/json' Autherization : Bearer "token" http://127.0.0.1:8000/api/snippet/delete/

### Response

    HTTP/1.1 200 OK
    Status: 200 OK
    Connection: close
    Content-Type: application/json
    {
    "data": "",
    "Success": 1,
    "Message": "Snippet Delete Successfully"
    }
    
### Input

    {
    "id":3
    }



## List Snippet

### Request

`POST /api/snippet/list/`

    curl -i -H 'Accept: application/json' Autherization : Bearer "token" http://127.0.0.1:8000/api/snippet/list/

### Response

    HTTP/1.1 200 OK
    Status: 200 OK
    Connection: close
    Content-Type: application/json
    {
    "data": [
        {
            "id": 1,
            "title": "creating",
            "timestamp": "2022-03-03T11:03:33.815008Z",
            "created_user": 2,
            "snippet": "creating texting"
        }
    ],
    "total": 1,
    "success": 1,
    "message": "customer list executed successfully"
    }
    
### Input

    {
        "search":"",
        "sort_col":"title",
        "sort":"1",  
        "page":"",
        "page_index":"10"
    }


## Tag List

### Request

`POST /api/tags/list/`

    curl -i -H 'Accept: application/json' Autherization : Bearer "token" http://127.0.0.1:8000/api/tags/list/

### Response

    HTTP/1.1 200 OK
    Status: 200 OK
    Connection: close
    Content-Type: application/json
    {
    "data": [
        {
            "id": 1,
            "title": "creating"
        }
    ],
    "total": 1,
    "Success": 1,
    "Message": "Taglist Created Successfully"
    }
    
### Input

    {

    }


## Tag Views (snippeds list)

### Request

`POST /api/tags/view/`

    curl -i -H 'Accept: application/json' Autherization : Bearer "token" http://127.0.0.1:8000/api/tags/view/

### Response

    HTTP/1.1 200 OK
    Status: 200 OK
    Connection: close
    Content-Type: application/json
    {"data":[],"total":0}
    
### Input

    {
    "id":1
    }

`id stands for tags id`

