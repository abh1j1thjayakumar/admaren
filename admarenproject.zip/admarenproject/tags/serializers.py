from rest_framework import serializers
from . models import tagModel


class tagSerializers(serializers.ModelSerializer):

    class Meta:

        model = tagModel
        fields = ['id', 'title']