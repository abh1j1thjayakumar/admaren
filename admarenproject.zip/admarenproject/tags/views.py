from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from . serializers import  tagSerializers
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework import permissions
from rest_framework.authentication import TokenAuthentication
from snippet.serializers import snippetSerializer
from snippet.models import SnippetModel
# Create your views here.
from . models import tagModel



class Taglist(APIView):
    permission_classes = [IsAuthenticated]
    
    def post(self,request):
        data = {}

        tags = tagModel.objects.all()
        serializer = tagSerializers(tags,many=True) 
        total = tags.count()
        data['data'] = serializer.data
        data['total'] = total
        data['Success'] = 1
        data['Message'] = 'Taglist Created Successfully'
        return Response(data,status=status.HTTP_200_OK)  

        

class tagView(APIView):
    permission_classes = [IsAuthenticated]
    

    def post(self, request):
        data = {}
        tag_id = request.data['id']
        tag_title = tagModel.objects.get(id=tag_id)
        snippet = SnippetModel.objects.filter(title=tag_title.title)
        serialize = snippetSerializer(snippet,many=True)
        data['data'] = serialize.data
        data['Success'] = 1
        data['message'] = 'snippet details view successfully'
        return Response(data,status=status.HTTP_200_OK)
