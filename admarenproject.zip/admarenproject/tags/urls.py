from django.contrib import admin
from django.urls import path
from . views import Taglist,tagView

urlpatterns = [
    path('list/',Taglist.as_view()),
    path('view/',tagView.as_view()),

    




    


]



