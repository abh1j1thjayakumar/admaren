from django.shortcuts import render
from rest_framework.views import APIView
from . serializers import  UsersSerializer
from rest_framework.response import Response
from rest_framework import status
from rest_framework.authtoken.models import Token
from . models import Users
from rest_framework.permissions import IsAuthenticated
from rest_framework import permissions
from rest_framework.authentication import TokenAuthentication
import jwt
from django.contrib.auth import authenticate


# Create your views here.


class ResgisterView(APIView):
    def post(self, request):
        data = {}

        serializer = UsersSerializer(data=request.data)
        if serializer.is_valid():
            user= serializer.save()
            
            data['data'] = serializer.data
            data['Success'] = 1
            data['Message'] = 'User Created Successfully'
            return Response(data,status=status.HTTP_200_OK)

        else:
            data['data'] = serializer.errors
            data['Success'] = 0
            data['Message'] = 'User Creation Failed'
            return Response(data,status=status.HTTP_400_BAD_REQUEST)
        


class LoginView(APIView):

    def post(self,request):
        data = {}
        email = request.data['email']
        password = request.data['password']

        try:
            UserData = Users.objects.get(email=email)
        except Users.DoesNotExist:
            data['Success'] = 0
            data['Message'] = 'User Does Not Exist'
            return Response(data,status=status.HTTP_404_NOT_FOUND)
        
        if UserData is None:
            data['Success'] = 0
            data['Message'] = 'User Does not Exist'
            return Response(data,status=status.HTTP_400_BAD_REQUEST)
        user = authenticate(email=email, password=password)
        
        if user:
            auth_token = jwt.encode({'email': email}, 'secret',algorithm='HS256')
        
            serializers = UsersSerializer(user)
            #token,create  = Token.objects.get_or_create(user=user)
            data['data'] = serializers.data
            data['token'] = auth_token
            data['success'] = 1
            data['Message'] = 'User Logged in Successfully'

            return Response(data,status=status.HTTP_200_OK)

        return Response({'error': 'Wrong Credentials'}, status=status.HTTP_401_UNAUTHORIZED)



class Logout(APIView):
    permission_classes = [permissions,IsAuthenticated]
    
    def post(self, request, format=None):
        data = {}
        # simply delete the token to force a login
        request.user.auth_token.delete()
        data['data'] = ''
        data['success'] = 1
        data['message'] = 'logout successfull'
        return Response(data,status=status.HTTP_200_OK)