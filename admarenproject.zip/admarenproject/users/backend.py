import jwt
from . models import Users
from rest_framework import authentication, exceptions



class JWTAuthentication(authentication.BaseAuthentication):

    def authenticate(self, request):

        auth_data = authentication.get_authorization_header(request)

        if not auth_data:
            return None

        auth_token= auth_data.decode('utf-8').split(" ")
        if len(auth_token) != 2:
            raise exceptions.AuthenticationFailed('Invalid token, please login again')

        token = auth_token[1]
        #print(token)
        try:
            payload = jwt.decode(token, 'secret',algorithms='HS256')
            user = Users.objects.get(email=payload['email'])
            #print(user)
            return (user, token)



            
        except jwt.ExpiredSignatureError:
            raise exceptions.AuthenticationFailed('Token has expired')
        except jwt.DecodeError as decode_error:
            raise exceptions.AuthenticationFailed('Invalid tokens')
        
        except Users.DoesNotExist:
            raise exceptions.AuthenticationFailed('User not found')
        return super().authenticate(request)


        '''try:
            payload = jwt.decode(token, 'secret',algorithm='HS256')
            user = Users.objects.get(email=payload['email'])
            return (user, token)

        except jwt.DecodeError as decode_error:
            raise exceptions.AuthenticationFailed('Invalid token')
        except jwt.ExpiredSignatureError as expired_error:
            raise exceptions.AuthenticationFailed('token is expired!!')'''


