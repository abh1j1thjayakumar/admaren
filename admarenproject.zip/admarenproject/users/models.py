from django.db import models
from django.utils.translation import gettext_lazy as lazy
from rest_framework.authtoken.models import Token
import jwt
from datetime import datetime, timedelta
from django.contrib.auth.models import AbstractUser,PermissionsMixin,BaseUserManager
# Create your models here.
class CustomAccountManager(BaseUserManager):


    def create_user(self,email, name, password,**other_fields):
        if not email:
            raise ValueError(lazy('please provide email address'))


        email = self.normalize_email(email)
        user = self.model(email=email,name=name,**other_fields)


        user.set_password(password)
        
        user.save()
        #token,create  = Token.objects.get_or_create(user=user)
        #dataT = token.key
        #print(dataT)
        

        return user


    def create_superuser(self,email, name, password,**other_fields):
        other_fields.setdefault('is_staff',True)
        other_fields.setdefault('is_superuser',True)
        other_fields.setdefault('is_active',True)
        


        if other_fields.get('is_staff') is not True:
            raise ValueError(
                'Superuser must be assigned to is_staff=True,'
            )

        if other_fields.get('is_superuser')is not True:
            raise ValueError(
                'Superuser must be assigned to is_superuser'
            )
        #user = create_superuser()
        #token,create  = Token.objects.get_or_create(user=instance)

        return self.create_user(email, name, password,**other_fields)         




class Users(AbstractUser,PermissionsMixin):

    name = models.CharField(max_length=90, null=False)
    email = models.CharField(max_length=199, null=False , unique=True)
    password = models.CharField(max_length=90, null=False)
    username = None

    objects = CustomAccountManager()

    USERNAME_FIELD = 'email'

    REQUIRED_FIELDS = ['name','password']

    def __str__(self):
        return self.email

    class Meta:
        db_table = 'users_db'



    @property
    def token(self):
        token = jwt.encode({'email': self.email,'exp':datetime.utcnow()+timedelta(hours=1)}, 'secret', algorithms='HS256')
        return token

    